import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.example.app',
  appName: 'mystory',
  webDir: 'dist/Code/Browser/'
};

export default config;
